import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrl: './status.component.css',
})
export class StatusComponent {
  @Input() show: boolean = false;
  @Input() status: boolean = true;
  @Input() message: string = '';
  @Input() messageDetails: string[] = [];
}
