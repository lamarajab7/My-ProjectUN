import { Component } from '@angular/core';
import {
  AbstractControlOptions,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { UserService } from '../auth/user.service';
import { User } from '../auth/user.model';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  registrationForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private appComponent: AppComponent
  ) {}

  ngOnInit() {
    this.registrationForm = this.fb.group(
      {
        username: [
          '',
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(20),
          ],
        ],
        email: [
          '',
          [
            Validators.required,
            Validators.email,
            Validators.maxLength(40),
            Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}'),
          ],
        ],
        password: [
          '',
          [
            Validators.required,
            Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[\\S]{8,40}$'),
            // Validators.pattern('^(?=.*?[a-z])(?=.*?[0-9]).{6,}$'),
          ],
        ],
        confirmPassword: ['', [Validators.required]],
      },
      { validators: [this.passwordMatchValidator] } as AbstractControlOptions
    );
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password').value;
    const confirmPassword = formGroup.get('confirmPassword').value;

    if (password === confirmPassword) {
      formGroup.get('confirmPassword').setErrors(null);
    } else {
      formGroup.get('confirmPassword').setErrors({ mismatch: true });
    }
  }

  onRegister() {
    if (this.registrationForm.valid) {
      const user: User = {
        name: this.registrationForm.get('username').value,
        email: this.registrationForm.get('email').value,
        password: this.registrationForm.get('password').value,
      };
      this.userService.register(user).subscribe({
        next: (response: any) => {
          console.log('User registered successfully:', response);
        },
        error: (err: any) => {
          const errorStatus = err['error']['status'];
          const errorMessage = err['error']['message'];
          const errorMessageDetails: string[] = [];
          const errors = err['error']['errors'];
          const errorKeys = Object.keys(errors);
          errorKeys.forEach((key) => {
            const errorMessages = errors[key];
            errorMessages.forEach((errorMessage) => {
              errorMessageDetails.push(`${errorMessage}`);
            });
          });
          this.appComponent.showStatusMessage(
            errorStatus,
            errorMessage,
            errorMessageDetails
          );
        },
      });
    }
  }
}
