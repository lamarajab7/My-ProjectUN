import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  show: boolean = false;
  status: boolean = false;
  message: string = '';
  messageDetails: string[] = [];

  showStatusMessage(
    status: boolean,
    message: string,
    messageDetails: string[]
  ) {
    this.show = true;
    this.status = status;
    this.message = message;
    this.messageDetails = messageDetails;
    setTimeout(() => {
      this.show = false;
    }, 5000);
  }
}
